<?php
    include_once "db_user.php";
//myprofile.php에서 저장하기 눌렀을 때 db에 수정되도록.