<?php
// answer.php에서 답변하기 클릭시 동작. db t_board 해당 row answer컬럼에 insert 됨.
// 동작 후 해당 row의 detail.php 페이지로 이동함