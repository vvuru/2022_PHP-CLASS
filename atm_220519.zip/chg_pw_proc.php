<?php
//chg_pw.php에서 저장하기 버튼 누를시 동작하며 t_user 해당 row의 upw 컬럼 수정됨
//동작 후 myprofile.php로 돌아감